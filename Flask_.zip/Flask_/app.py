from flask import Flask, request, render_template, json, make_response

app = Flask(__name__)


@app.route('/') # @-Annotation
def hello_world():
    return 'Hello World!' + request.path


@app.route('/hello')
def hello():
    return 'Hiii'


@app.route('/tmp')
def root():
    return "Root !!!"


@app.route('/hello1/')
@app.route('/hello1/<fromPagename>')
def test(fromPagename=None):
    return render_template("homepage.html",name=fromPagename)

@app.route('/data',methods=['GET'])
def show_data():
    return "Get Displaying"

@app.route('/data',methods=['POST'])
def handle_data():
    return "post Displaying"

@app.route('/user/<username>')
def greet(username):
    return 'Helloo ' + username

@app.route("/json")
def get_image():
    response = make_response(json.dumps({"foo": "bar"}))
    response.mimetype = "application/json"
    return response

@app.route("/error")
def error_page():
    response=make_response("Error Page")
    response.status_code = 404
    return response

@app.route("/post")
@app.route("/post/page/<int:page_nb>")
def show_post(page_nb=1):
    first_msg= 1+50*page_nb
    last_msg=first_msg+49
    return "Message "+ str(page_nb)

if __name__ == '__main__':
    app.run()
